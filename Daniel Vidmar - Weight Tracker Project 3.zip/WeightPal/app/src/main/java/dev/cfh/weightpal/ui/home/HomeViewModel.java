package dev.cfh.weightpal.ui.home;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class HomeViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public HomeViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This will be home to quick data, maybe a chart/graph for recent entries.");
    }

    public LiveData<String> getText() {
        return mText;
    }
}