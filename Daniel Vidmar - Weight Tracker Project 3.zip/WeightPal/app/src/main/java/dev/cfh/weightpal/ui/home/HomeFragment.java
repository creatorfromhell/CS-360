package dev.cfh.weightpal.ui.home;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import dev.cfh.weightpal.data.DatabaseHelper;
import dev.cfh.weightpal.databinding.FragmentHomeBinding;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    private SQLiteDatabase database;
    private String loggedInUsername;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        DatabaseHelper dbHelper = new DatabaseHelper(requireContext());
        database = dbHelper.getWritableDatabase();

        // Retrieve the logged-in user's username
        loggedInUsername = requireActivity()
                .getSharedPreferences("WeightPalPrefs", requireContext().MODE_PRIVATE)
                .getString("loggedInUsername", null);

        if (loggedInUsername == null) {
            Toast.makeText(requireContext(), "Please log in first.", Toast.LENGTH_SHORT).show();
            requireActivity().finish();
            return root;
        }

        // Setup UI components
        TextView currentGoal = binding.weightCurrentGoal;
        EditText weightGoalInput = binding.weightGoalInput;
        Button updateGoalButton = binding.updateGoalButton;

        // Load existing goal from database or set default
        String existingGoal = getExistingWeightGoal();
        currentGoal.setText("Current Goal: " + (existingGoal != null ? existingGoal : "None"));

        updateGoalButton.setOnClickListener(v -> {
            String weightGoal = weightGoalInput.getText().toString().trim();

            if (TextUtils.isEmpty(weightGoal)) {
                Toast.makeText(requireContext(), "Please enter a weight goal.", Toast.LENGTH_SHORT).show();
                return;
            }

            ContentValues values = new ContentValues();
            values.put("username", loggedInUsername);
            values.put("goal", weightGoal);
            values.put("date", System.currentTimeMillis());

            database.insert("goal_history", null, values);

            currentGoal.setText("Current Goal: " + weightGoal);

            // Save the updated goal to SharedPreferences
            requireActivity().getSharedPreferences("WeightPalPrefs", requireContext().MODE_PRIVATE)
                    .edit()
                    .putString("weightGoal", weightGoal)
                    .apply();

            Toast.makeText(requireContext(), "Weight goal updated!", Toast.LENGTH_SHORT).show();
            weightGoalInput.setText(weightGoal);
        });

        return root;
    }

    private String getExistingWeightGoal() {
        Cursor cursor = database.query(
                "goal_history",
                new String[]{"goal"},
                "username = ?",
                new String[]{loggedInUsername},
                null, null, "date DESC",
                "1"
        );

        if (cursor != null && cursor.moveToFirst()) {
            String goal = cursor.getString(cursor.getColumnIndex("goal"));
            cursor.close();
            return goal;
        }

        if (cursor != null) {
            cursor.close();
        }

        return null;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
        if (database != null) {
            database.close();
        }
    }
}