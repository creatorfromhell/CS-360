package dev.cfh.weightpal.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database and table names
    public static final String DATABASE_NAME = "weightpal.db";
    public static final int DATABASE_VERSION = 3; // Incremented for updated table structure

    // Users table
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USER_USERNAME = "username";
    public static final String COLUMN_USER_PASSWORD = "password";

    // Weights table
    public static final String TABLE_WEIGHTS = "weights";
    public static final String COLUMN_WEIGHTS_USERNAME = "username";
    public static final String COLUMN_WEIGHTS_DATE = "date";
    public static final String COLUMN_WEIGHTS_WEIGHT = "weight";

    // Weight goals history table
    public static final String TABLE_GOAL_HISTORY = "goal_history";
    public static final String COLUMN_GOAL_HISTORY_USERNAME = "username";
    public static final String COLUMN_GOAL_HISTORY_DATE = "date";
    public static final String COLUMN_GOAL_HISTORY_GOAL = "goal";

    // Workouts table
    public static final String TABLE_WORKOUTS = "workouts";
    public static final String COLUMN_WORKOUTS_USERNAME = "username";
    public static final String COLUMN_WORKOUTS_DATE = "date";

    // Workout tracking table
    public static final String TABLE_WORKOUT_TRACKING = "workout_tracking";
    public static final String COLUMN_TRACKING_USERNAME = "username";
    public static final String COLUMN_TRACKING_DATE = "date";
    public static final String COLUMN_TRACKING_GROUP = "muscle_group";
    public static final String COLUMN_TRACKING_REPS = "reps";
    public static final String COLUMN_TRACKING_WEIGHT = "weight";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                + COLUMN_USER_USERNAME + " TEXT PRIMARY KEY, "
                + COLUMN_USER_PASSWORD + " TEXT NOT NULL);");

        // Create weights table
        db.execSQL("CREATE TABLE " + TABLE_WEIGHTS + " ("
                + COLUMN_WEIGHTS_USERNAME + " TEXT NOT NULL, "
                + COLUMN_WEIGHTS_DATE + " INTEGER PRIMARY KEY, "
                + COLUMN_WEIGHTS_WEIGHT + " TEXT NOT NULL, "
                + "FOREIGN KEY(" + COLUMN_WEIGHTS_USERNAME + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_USERNAME + "));");

        // Create goal history table
        db.execSQL("CREATE TABLE " + TABLE_GOAL_HISTORY + " ("
                + COLUMN_GOAL_HISTORY_USERNAME + " TEXT NOT NULL, "
                + COLUMN_GOAL_HISTORY_DATE + " INTEGER NOT NULL, "
                + COLUMN_GOAL_HISTORY_GOAL + " TEXT NOT NULL, "
                + "PRIMARY KEY(" + COLUMN_GOAL_HISTORY_USERNAME + ", " + COLUMN_GOAL_HISTORY_DATE + "), "
                + "FOREIGN KEY(" + COLUMN_GOAL_HISTORY_USERNAME + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_USERNAME + "));");

        // Create workouts table
        db.execSQL("CREATE TABLE " + TABLE_WORKOUTS + " ("
                + COLUMN_WORKOUTS_USERNAME + " TEXT NOT NULL, "
                + COLUMN_WORKOUTS_DATE + " TEXT PRIMARY KEY, "
                + "FOREIGN KEY(" + COLUMN_WORKOUTS_USERNAME + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_USERNAME + "));");

        // Create workout tracking table
        db.execSQL("CREATE TABLE " + TABLE_WORKOUT_TRACKING + " ("
                + COLUMN_TRACKING_USERNAME + " TEXT NOT NULL, "
                + COLUMN_TRACKING_DATE + " TEXT, "
                + COLUMN_TRACKING_GROUP + " TEXT, "
                + COLUMN_TRACKING_REPS + " INTEGER, "
                + COLUMN_TRACKING_WEIGHT + " TEXT, "
                + "PRIMARY KEY(" + COLUMN_TRACKING_USERNAME + ", " + COLUMN_TRACKING_DATE + ", " + COLUMN_TRACKING_GROUP + "), "
                + "FOREIGN KEY(" + COLUMN_TRACKING_USERNAME + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_USERNAME + "));");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop existing tables if database is upgraded
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL_HISTORY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WORKOUTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WORKOUT_TRACKING);
        onCreate(db);
    }
}