package dev.cfh.weightpal.ui.dashboard;

import android.content.Context;
import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import dev.cfh.weightpal.R;
import dev.cfh.weightpal.data.WeightEntry;

public class WeightGridAdapter extends BaseAdapter {

    private final Context context;
    private final List<Map.Entry<Long, WeightEntry>> weights;
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
    private final SQLiteDatabase database;

    public WeightGridAdapter(Context context, List<Map.Entry<Long, WeightEntry>> weights, SQLiteDatabase database) {
        this.context = context;
        this.weights = weights;
        this.database = database;
    }

    @Override
    public int getCount() {
        return weights.size();
    }

    @Override
    public Object getItem(int position) {
        return weights.get(position);
    }

    @Override
    public long getItemId(int position) {
        return weights.get(position).getKey();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.weight_item, parent, false);
        }

        TextView weightText = convertView.findViewById(R.id.weightTextView);
        TextView timestampText = convertView.findViewById(R.id.dateTextView);
        Button deleteButton = convertView.findViewById(R.id.deleteButton);

        // Get the current weight entry
        Map.Entry<Long, WeightEntry> entry = weights.get(position);
        timestampText.setText(dateFormat.format(new Date(entry.getKey())));
        weightText.setText(String.valueOf(entry.getValue().getWeight()));

        // Set the delete button click listener
        deleteButton.setOnClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Delete Entry")
                    .setMessage("Are you sure you want to delete this weight entry?")
                    .setPositiveButton("Yes", (DialogInterface dialog, int which) -> {
                        database.delete("weights", "date = ?", new String[]{String.valueOf(entry.getKey())});
                        weights.remove(position);
                        notifyDataSetChanged();
                        Toast.makeText(context, "Weight entry deleted.", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("No", null)
                    .show();
        });

        return convertView;
    }
}