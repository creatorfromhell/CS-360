package dev.cfh.weightpal.data;

import java.util.TreeMap;

public class WeightManager {

    public static final WeightManager instance = new WeightManager();

    private WeightManager() {
        // Populate the WeightManager map with example data
        weights.put(
                1672531200000L, // Example timestamp in milliseconds (Jan 1, 2023)
                new WeightEntry(1672531200000L, "70.5 kg")
        );

        weights.put(
                1672617600000L, // Example timestamp in milliseconds (Jan 2, 2023)
                new WeightEntry(1672617600000L, "70.3 kg")
        );

        weights.put(
                1672704000000L, // Example timestamp in milliseconds (Jan 3, 2023)
                new WeightEntry(1672704000000L, "70.4 kg")
        );

        weights.put(
                1672790400000L, // Example timestamp in milliseconds (Jan 4, 2023)
                new WeightEntry(1672790400000L, "70.2 kg")
        );
    }

    protected final TreeMap<Long, WeightEntry> weights = new TreeMap<>();

    public TreeMap<Long, WeightEntry> getWeights() {
        return weights;
    }
}