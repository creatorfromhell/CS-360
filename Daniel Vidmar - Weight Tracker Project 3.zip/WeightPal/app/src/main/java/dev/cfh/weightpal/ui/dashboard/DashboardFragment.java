package dev.cfh.weightpal.ui.dashboard;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import dev.cfh.weightpal.LoginActivity;
import dev.cfh.weightpal.R;
import dev.cfh.weightpal.data.DatabaseHelper;
import dev.cfh.weightpal.data.WeightEntry;
import dev.cfh.weightpal.ui.dashboard.WeightGridAdapter;

public class DashboardFragment extends Fragment {

    private SQLiteDatabase database;
    private String currentWeightGoal = "70"; // Example goal
    private String loggedInUsername; // Logged-in user's username

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        DatabaseHelper dbHelper = new DatabaseHelper(requireContext());
        database = dbHelper.getWritableDatabase();

        View root = inflater.inflate(R.layout.fragment_dashboard, container, false);

        GridView weightsView = root.findViewById(R.id.weightsView);
        TextView notice = root.findViewById(R.id.textNotice);
        EditText inputDate = root.findViewById(R.id.inputDate);
        EditText inputWeight = root.findViewById(R.id.inputWeight);
        Button addButton = root.findViewById(R.id.addButton);

        // Retrieve the logged-in user's username from arguments or shared preferences
        if (getArguments() != null) {
            loggedInUsername = getArguments().getString("loggedInUsername");
        } else {
            loggedInUsername = requireActivity()
                    .getSharedPreferences("WeightPalPrefs", requireContext().MODE_PRIVATE)
                    .getString("loggedInUsername", null);
        }

        // Redirect to LoginActivity if loggedInUsername is null
        if (loggedInUsername == null) {
            Intent intent = new Intent(requireContext(), LoginActivity.class);
            startActivity(intent);
            requireActivity().finish();
            return null;
        }

        currentWeightGoal = requireActivity().getSharedPreferences("WeightPalPres", requireContext().MODE_PRIVATE)
                .getString("weightGoal", null);

        // Load weight data and configure adapter
        List<Map.Entry<Long, WeightEntry>> weightList = loadWeightsFromDatabase();
        WeightGridAdapter adapter = new WeightGridAdapter(requireContext(), weightList, database);

        if (weightList.size() > 0) {
            notice.setVisibility(View.GONE);

            // Add the header above the GridView
            View header = inflater.inflate(R.layout.weight_header, container, false);
            ViewGroup parent = (ViewGroup) weightsView.getParent();
            int index = parent.indexOfChild(weightsView);
            parent.addView(header, index);

            weightsView.setAdapter(adapter);
            weightsView.setVisibility(View.VISIBLE);
        } else {
            weightsView.setVisibility(View.GONE);
            notice.setVisibility(View.VISIBLE);
        }

        // Add button functionality
        addButton.setOnClickListener(v -> {
            String dateStr = inputDate.getText().toString().trim();
            String weightStr = inputWeight.getText().toString().trim();

            if (!dateStr.isEmpty() && !weightStr.isEmpty()) {
                try {
                    SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
                    Date date = dateFormat.parse(dateStr);

                    if (date != null) {
                        long timestamp = date.getTime();

                        ContentValues values = new ContentValues();
                        values.put("username", loggedInUsername);
                        values.put("date", timestamp);
                        values.put("weight", weightStr);
                        database.insert("weights", null, values);

                        weightList.add(new AbstractMap.SimpleEntry<>(timestamp, new WeightEntry(timestamp, weightStr)));
                        adapter.notifyDataSetChanged();

                        if (weightStr.equals(currentWeightGoal)) {
                            sendGoalAchievedSMS();
                        }

                        notice.setVisibility(View.GONE);
                        weightsView.setVisibility(View.VISIBLE);
                        inputDate.setText("");
                        inputWeight.setText("");
                    }
                } catch (ParseException e) {
                    Toast.makeText(requireContext(), "Invalid date format. Use MM-DD-YYYY.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(requireContext(), "Please enter both date and weight.", Toast.LENGTH_SHORT).show();
            }
        });

        return root;
    }

    private List<Map.Entry<Long, WeightEntry>> loadWeightsFromDatabase() {
        List<Map.Entry<Long, WeightEntry>> weightList = new ArrayList<>();
        Cursor cursor = database.query(
                "weights",
                null,
                "username = ?",
                new String[]{loggedInUsername},
                null, null, "date ASC"
        );

        while (cursor.moveToNext()) {
            long date = cursor.getLong(cursor.getColumnIndex("date"));
            String weight = cursor.getString(cursor.getColumnIndex("weight"));
            weightList.add(new AbstractMap.SimpleEntry<>(date, new WeightEntry(date, weight)));
        }

        cursor.close();
        return weightList;
    }

    private void sendGoalAchievedSMS() {
        SmsManager smsManager = SmsManager.getDefault();
        String message = "Congratulations! You've achieved your weight goal of " + currentWeightGoal;
        try {
            smsManager.sendTextMessage("1234567890", null, message, null, null);
            Toast.makeText(requireContext(), "SMS sent!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(requireContext(), "Failed to send SMS.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (database != null) {
            database.close();
        }
    }
}