package dev.cfh.weightpal.data;

public class WeightEntry {
    private Long date;
    private String weight;

    public WeightEntry(Long date, String weight) {
        this.date = date;
        this.weight = weight;
    }

    public Long getDate() {
        return date;
    }

    public void setDate(Long date) {
        this.date = date;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }
}