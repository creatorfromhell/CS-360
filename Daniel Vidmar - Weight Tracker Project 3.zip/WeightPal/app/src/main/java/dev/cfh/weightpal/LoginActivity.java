package dev.cfh.weightpal;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import dev.cfh.weightpal.data.DatabaseHelper;

public class LoginActivity extends AppCompatActivity {

    protected boolean signUp = false;
    private SQLiteDatabase database;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_login);
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        database = dbHelper.getWritableDatabase();
        sharedPreferences = getSharedPreferences("WeightPalPrefs", MODE_PRIVATE);

        Button btnAction = findViewById(R.id.btnAction);
        btnAction.setOnClickListener(view -> validateLogin());
    }

    public void toggleSignInSignUp(View view) {
        TextView textNotice = findViewById(R.id.textAccount);
        Button btnAction = findViewById(R.id.btnAction);

        AlphaAnimation fadeOut = new AlphaAnimation(1.0f, 0.0f);
        fadeOut.setDuration(300);

        AlphaAnimation fadeIn = new AlphaAnimation(0.0f, 1.0f);
        fadeIn.setDuration(300);

        textNotice.startAnimation(fadeOut);
        btnAction.startAnimation(fadeOut);

        fadeOut.setAnimationListener(new android.view.animation.Animation.AnimationListener() {
            @Override
            public void onAnimationStart(android.view.animation.Animation animation) {}

            @Override
            public void onAnimationEnd(android.view.animation.Animation animation) {
                if (signUp) {
                    btnAction.setText("Sign In");
                    textNotice.setText("No Account? Click here to sign up!");
                    signUp = false;
                } else {
                    btnAction.setText("Sign Up");
                    textNotice.setText("Have an Account? Click here to sign in!");
                    signUp = true;
                }

                textNotice.startAnimation(fadeIn);
                btnAction.startAnimation(fadeIn);
            }

            @Override
            public void onAnimationRepeat(android.view.animation.Animation animation) {}
        });
    }

    private void validateLogin() {
        EditText usernameField = findViewById(R.id.weightUsername);
        EditText passwordField = findViewById(R.id.weightPassword);

        String username = usernameField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();

        String encryptedPassword = encryptPassword(password);

        if (signUp) {
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            ContentValues values = new ContentValues();
            values.put("username", username);
            values.put("password", encryptedPassword);
            database.insert("users", null, values);

            Toast.makeText(this, "Account created! Please sign in.", Toast.LENGTH_SHORT).show();
            toggleSignInSignUp(null);

        } else {
            Cursor cursor = database.query(
                    "users",
                    new String[]{"username", "password"},
                    "username = ? AND password = ?",
                    new String[]{username, encryptedPassword},
                    null, null, null
            );

            if (cursor.moveToFirst()) {
                // Save the logged-in username in SharedPreferences
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("loggedInUsername", username);
                editor.apply();

                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }

            cursor.close();
        }
    }

    private String encryptPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());
            return Base64.encodeToString(hash, Base64.DEFAULT).trim();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return password;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (database != null) {
            database.close();
        }
    }
}