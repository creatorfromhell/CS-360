package dev.cfh.weightpal.ui.workouts;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

import dev.cfh.weightpal.R;
import dev.cfh.weightpal.data.DatabaseHelper;

public class WorkoutsFragment extends Fragment {

    private SQLiteDatabase database;
    private ArrayAdapter<String> adapter;
    private List<String> workoutDates;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        DatabaseHelper dbHelper = new DatabaseHelper(requireContext());
        database = dbHelper.getWritableDatabase();

        View root = inflater.inflate(R.layout.fragment_workouts, container, false);

        ListView workoutsListView = root.findViewById(R.id.workoutsListView);
        EditText inputWorkoutDate = root.findViewById(R.id.inputWorkoutDate);
        Button addWorkoutButton = root.findViewById(R.id.addWorkoutButton);

        workoutDates = loadWorkoutDatesFromDatabase();
        adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_list_item_1, workoutDates);
        workoutsListView.setAdapter(adapter);

        addWorkoutButton.setOnClickListener(v -> {
            String date = inputWorkoutDate.getText().toString().trim();

            if (!date.isEmpty()) {
                ContentValues values = new ContentValues();
                values.put("date", date);
                database.insert("workouts", null, values);

                workoutDates.add(date);
                adapter.notifyDataSetChanged();
                inputWorkoutDate.setText("");
                Toast.makeText(requireContext(), "Workout date added!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(requireContext(), "Please enter a workout date.", Toast.LENGTH_SHORT).show();
            }
        });

        workoutsListView.setOnItemClickListener((AdapterView<?> parent, View view, int position, long id) -> {
            String selectedDate = workoutDates.get(position);

            Bundle bundle = new Bundle();
            bundle.putString("selectedDate", selectedDate);

            //Navigation.findNavController(view).navigate(R.id.action_workoutsFragment_to_workoutDetailsFragment, bundle);
        });

        return root;
    }

    private List<String> loadWorkoutDatesFromDatabase() {
        List<String> dates = new ArrayList<>();
        Cursor cursor = database.query("workouts", new String[]{"date"}, null, null, null, null, "date ASC");

        while (cursor.moveToNext()) {
            dates.add(cursor.getString(cursor.getColumnIndex("date")));
        }

        cursor.close();
        return dates;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (database != null) {
            database.close();
        }
    }
}