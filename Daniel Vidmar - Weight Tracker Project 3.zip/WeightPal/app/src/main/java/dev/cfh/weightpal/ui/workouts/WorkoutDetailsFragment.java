package dev.cfh.weightpal.ui.workouts;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

import dev.cfh.weightpal.R;
import dev.cfh.weightpal.data.DatabaseHelper;

public class WorkoutDetailsFragment extends Fragment {

    private SQLiteDatabase database;
    private String selectedDate;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        try (DatabaseHelper dbHelper = new DatabaseHelper(requireContext())) {
            database = dbHelper.getWritableDatabase();
        }

        View root = inflater.inflate(R.layout.fragment_workout_details, container, false);

        TextView dateTextView = root.findViewById(R.id.workoutDateTextView);
        Spinner muscleGroupSpinner = root.findViewById(R.id.muscleGroupSpinner);
        EditText repsInput = root.findViewById(R.id.repsInput);
        EditText weightInput = root.findViewById(R.id.weightInput);
        Button addEntryButton = root.findViewById(R.id.addWorkoutEntryButton);

        if (getArguments() != null) {
            selectedDate = getArguments().getString("selectedDate");
            dateTextView.setText("Workout Date: " + selectedDate);
        }

        setupMuscleGroupSpinner(muscleGroupSpinner);

        addEntryButton.setOnClickListener(v -> {
            String muscleGroup = muscleGroupSpinner.getSelectedItem().toString();
            String reps = repsInput.getText().toString().trim();
            String weight = weightInput.getText().toString().trim();

            if (!muscleGroup.isEmpty() && !reps.isEmpty() && !weight.isEmpty()) {
                ContentValues values = new ContentValues();
                values.put("date", selectedDate);
                values.put("muscle_group", muscleGroup);
                values.put("reps", Integer.parseInt(reps));
                values.put("weight", weight);
                database.insert("workout_tracking", null, values);

                Toast.makeText(requireContext(), "Workout entry added!", Toast.LENGTH_SHORT).show();
                repsInput.setText("");
                weightInput.setText("");
            } else {
                Toast.makeText(requireContext(), "Please fill in all fields.", Toast.LENGTH_SHORT).show();
            }
        });

        return root;
    }

    private void setupMuscleGroupSpinner(Spinner spinner) {
        List<String> muscleGroups = new ArrayList<>();
        muscleGroups.add("Biceps");
        muscleGroups.add("Triceps");
        muscleGroups.add("Chest");
        muscleGroups.add("Back");
        muscleGroups.add("Shoulders");
        muscleGroups.add("Legs");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, muscleGroups);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (database != null) {
            database.close();
        }
    }
}
